<!DOCTYPE html>
<html>
<body>

<?php
echo "My new page by Vinod VERSION 22 ";
?>

</body>
</html>